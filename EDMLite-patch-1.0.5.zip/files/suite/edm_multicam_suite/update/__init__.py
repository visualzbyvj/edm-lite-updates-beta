"""Lite update channel: signed patch verification + apply (stdlib only)."""

# release-v2 live test 1.0.5
