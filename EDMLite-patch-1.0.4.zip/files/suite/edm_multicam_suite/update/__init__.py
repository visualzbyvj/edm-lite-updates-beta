"""Lite update channel: signed patch verification + apply (stdlib only)."""

# e2e-restart-marker 1.0.4
