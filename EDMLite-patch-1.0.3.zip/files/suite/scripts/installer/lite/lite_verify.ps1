# Lite post-install smoke check. PowerShell 5.1 compatible. Prints PASS/FAIL lines; exit 1 on any FAIL.
# Run manually from the installed suite:
#   powershell -NoProfile -ExecutionPolicy Bypass -File "<suite>\scripts\installer\lite\lite_verify.ps1"
param(
    [string]$SuiteRoot = "",
    [string]$PluginDir = ""
)

$ErrorActionPreference = "Continue"
if (-not $SuiteRoot) {
    # Script lives at <suite>\scripts\installer\lite\
    $SuiteRoot = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
}
$SuiteRoot = [System.IO.Path]::GetFullPath($SuiteRoot)
if (-not $PluginDir) { $PluginDir = Split-Path -Parent $SuiteRoot }

$script:fails = 0
$script:passes = 0

function Write-Result([bool]$Ok, [string]$Name, [string]$Detail) {
    if ($Ok) { $script:passes++; $tag = "PASS" } else { $script:fails++; $tag = "FAIL" }
    Write-Host ("{0}  {1} - {2}" -f $tag, $Name, $Detail)
}

function Test-File([string]$Name, [string]$Path) {
    $ok = Test-Path -LiteralPath $Path
    Write-Result $ok $Name $Path
}

function Invoke-Probe([string]$Exe, [string]$Arguments, [string]$WorkDir) {
    $tag = [guid]::NewGuid().ToString("N")
    $outFile = Join-Path $env:TEMP "edm_verify_$tag.out.txt"
    $errFile = Join-Path $env:TEMP "edm_verify_$tag.err.txt"
    try {
        $p = Start-Process -FilePath $Exe -ArgumentList $Arguments -WorkingDirectory $WorkDir -NoNewWindow -Wait -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        $out = @()
        $err = @()
        if (Test-Path -LiteralPath $outFile) { $out = @(Get-Content -LiteralPath $outFile) }
        if (Test-Path -LiteralPath $errFile) { $err = @(Get-Content -LiteralPath $errFile) }
        return [pscustomobject]@{ ExitCode = $p.ExitCode; Stdout = $out; Stderr = $err }
    } catch {
        return [pscustomobject]@{ ExitCode = -1; Stdout = @(); Stderr = @($_.Exception.Message) }
    } finally {
        foreach ($f in @($outFile, $errFile)) { if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } }
    }
}

Write-Host "Lite verify: SuiteRoot=$SuiteRoot PluginDir=$PluginDir"

# Plugin shell
Test-File "plugin manifest" (Join-Path $PluginDir "manifest.xml")
Test-File "plugin main.js" (Join-Path $PluginDir "main.js")
Test-File "plugin index.html" (Join-Path $PluginDir "index.html")
Test-File "plugin WorkflowIntegration.node" (Join-Path $PluginDir "WorkflowIntegration.node")

# Suite payload
Test-File "suite config" (Join-Path $SuiteRoot "config\config.json")
Test-File "suite LITE_VERSION" (Join-Path $SuiteRoot "LITE_VERSION.json")
Test-File "suite edm_multicam_suite" (Join-Path $SuiteRoot "edm_multicam_suite")
Test-File "suite edm_gig_pipeline" (Join-Path $SuiteRoot "edm_gig_pipeline")
Test-File "suite tmp dir" (Join-Path $SuiteRoot "tmp")

# Config portability: no build-machine literals
$cfgPath = Join-Path $SuiteRoot "config\config.json"
if (Test-Path -LiteralPath $cfgPath) {
    $cfgText = Get-Content -LiteralPath $cfgPath -Raw
    $bad = @()
    if ($cfgText -match '(?i)C:[\\/]+Users[\\/]+vjcec') { $bad += "build-machine user profile path" }
    if ($cfgText -match 'E:[\\/]+AI STUFF') { $bad += "build-machine dev drive path" }
    Write-Result ($bad.Count -eq 0) "config portability" ($(if ($bad.Count -eq 0) { "no build-machine paths" } else { "found: " + ($bad -join ", ") }))
}

# Bundled Python base
$basePy = Join-Path $SuiteRoot "runtime\python312\python.exe"
if (Test-Path -LiteralPath $basePy) {
    $r = Invoke-Probe $basePy "-c `"import sys; print(sys.version)`"" $SuiteRoot
    $ver = ($r.Stdout -join " ").Trim()
    Write-Result (($r.ExitCode -eq 0) -and ($ver -like "3.12*")) "bundled python 3.12" $ver
    # App-local VC++ runtime so torch loads on a PC without the redistributable.
    foreach ($rt in @("vcruntime140.dll", "vcruntime140_1.dll", "msvcp140.dll")) {
        Test-File ("app-local $rt") (Join-Path (Split-Path -Parent $basePy) $rt)
    }
} else {
    Write-Result $false "bundled python 3.12" "missing $basePy"
}

# Worker venv + daemon import
$venvPy = Join-Path $SuiteRoot ".venv_worker_gpu\Scripts\python.exe"
if (Test-Path -LiteralPath $venvPy) {
    $env:EDM_GATE_NO_RESOLVE = "1"
    $env:PYTHONPATH = $SuiteRoot
    $env:PYTHONDONTWRITEBYTECODE = "1"
    $env:RESOLVE_EDM_SUITE_ROOT = $SuiteRoot
    $r = Invoke-Probe $venvPy "-c `"import sys; print(sys.version)`"" $SuiteRoot
    Write-Result ($r.ExitCode -eq 0) "worker venv python" ($r.Stdout -join " ")
    $r = Invoke-Probe $venvPy "-c `"import edm_multicam_suite.pass_state.daemon`"" $SuiteRoot
    Write-Result ($r.ExitCode -eq 0) "daemon import" ("exit " + $r.ExitCode)
} else {
    Write-Result $false "worker venv python" "missing $venvPy"
    Write-Result $false "daemon import" "skipped (no venv)"
}

# ffmpeg
$ffmpeg = Join-Path $SuiteRoot "tools\ffmpeg\ffmpeg.exe"
if (Test-Path -LiteralPath $ffmpeg) {
    $r = Invoke-Probe $ffmpeg "-version" $SuiteRoot
    $first = ""
    if ($r.Stdout.Count -gt 0) { $first = [string]$r.Stdout[0] }
    Write-Result ($r.ExitCode -eq 0) "ffmpeg -version" $first
} else {
    Write-Result $false "ffmpeg -version" "missing $ffmpeg"
}

# AutoHotkey v2
$ahk = Join-Path $SuiteRoot "tools\autohotkey-v2\v2\AutoHotkey64.exe"
if (Test-Path -LiteralPath $ahk) {
    $ahkVer = [string]((Get-Item -LiteralPath $ahk).VersionInfo.ProductVersion)
    Write-Result ($ahkVer -like "2.*") "AutoHotkey v2" ("$ahk ($ahkVer)")
} else {
    Write-Result $false "AutoHotkey v2" "missing $ahk"
}

Write-Host ("SUMMARY pass={0} fail={1}" -f $script:passes, $script:fails)
if ($script:fails -gt 0) { exit 1 }
exit 0

# e2e-update-marker 1.0.3
